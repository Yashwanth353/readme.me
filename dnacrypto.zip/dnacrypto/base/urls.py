from . import views
from django.urls import re_path


urlpatterns = [
    re_path(r'^home/$',views.first,name='first'),
    re_path(r'^encrypt/$',views.encrypt,name='encrypt'),
    re_path(r'^encryption/$',views.getdata,name='using'),
    re_path(r'^decrypt/$',views.decrypt,name='decrypt'),
    re_path(r'^decryption/$',views.senddata,name='senddata'),
]
