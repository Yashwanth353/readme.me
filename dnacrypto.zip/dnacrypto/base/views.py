
from django.shortcuts import render,get_object_or_404,redirect
# Create your views here.

aminoacid={

    "CGGA": "E1",
    "CGUA": "Q4",
    "CGAA": "G7",
    "CGCA": "HA",
    "CGCU": "A1",
    "CGAU": "R4",
    "CGUU": "N7",
    "CGGU": "DA",
    "CGGC": "L1",
    "CGUC": "K4",
    "CGAC": "M7",
    "CGCC": "FA",
    "CGCG": "S1",
    "CGAG": "U4",
    "CGUG": "W7",
    "CGGG": "YA",
    "AGGA": "E2",
    "AGUA": "Q5",
    "AGAA": "G8",
    "AGCA": "HB",
    "AGCU": "A2",
    "AGAU": "R5",
    "AGUU": "N8",
    "AGGU": "DB",
    "AGGC": "L2",
    "AGUC": "K5",
    "AGAC": "M8",
    "AGCC": "FB",
    "AGCG": "S2",
    "AGAG": "U5",
    "AGUG": "W8",
    "AGGG": "YB",
    "UGGA": "E3",
    "UGUA": "Q6",
    "UGAA": "G9",
    "UGCA": "HC",
    "UGCU": "A3",
    "UGAU": "R6",
    "UGUU": "N9",
    "UGGU": "DC",
    "UGGC": "L3",
    "UGUC": "K6",
    "UGAC": "M9",
    "UGCC": "FC",
    "UGCG": "S3",
    "UGAG": "U6",
    "UGUG": "W9",
    "UGGG": "YC",
    "GGGA": "E4",
    "GGUA": "Q7",
    "GGAA": "GA",
    "GGCA": "HD",
    "GGCU": "A4",
    "GGAU": "R7",
    "GGUU": "NA",
    "GGGU": "DD",
    "GGGC": "L4",
    "GGUC": "K7",
    "GGAC": "MA",
    "GGCC": "FD",
    "GGCG": "S4",
    "GGAG": "U7",
    "GGUG": "WA",
    "GGGG": "YD",
    "GCGA": "E5",
    "GCUA": "Q8",
    "GCAA": "GB",
    "GCCA": "I1",
    "GCCU": "A5",
    "GCAU": "R8",
    "GCUU": "NB",
    "GCGU": "C1",
    "GCGC": "L5",
    "GCUC": "K8",
    "GCAC": "MB",
    "GCCC": "P1",
    "GCCG": "S5",
    "GCAG": "U8",
    "GCUG": "WB",
    "GCGG": "V1",
    "UCGA": "E6",
    "UCUA": "Q9",
    "UCAA": "GC",
    "UCCA": "I2",
    "UCCU": "A6",
    "UCAU": "R9",
    "UCUU": "NC",
    "UCGU": "C2",
    "UCGC": "L6",
    "UCUC": "K9",
    "UCAC": "MC",
    "UCCC": "P2",
    "UCCG": "S6",
    "UCAG": "U9",
    "UCUG": "WC",
    "UCGG": "V2",
    'ACGA': 'E7',
    'ACUA': 'QA',
    'ACAA': 'GD',
    'ACCA': 'I3',
    'ACCU': 'A7',
    'ACAU': 'RA',
    'ACUU': 'ND',
    'ACGU': 'C3',
    'ACGC': 'L7',
    'ACUC': 'KA',
    'ACAC': 'MD',
    'ACCC': 'P3',
    'ACCG': 'S7',
    'ACAG': 'UA',
    'ACUG': 'WD',
    'ACGG': 'V3',
    'CCGA': 'E8',
    'CCUA': 'QB',
    'CCAA': 'H1',
    'CCCA': 'I4',
    'CCCU': 'A8',
    'CCAU': 'RB',
    'CCUU': 'D1',
    'CCGU': 'C4',
    'CCGC': 'L8',
    'CCUC': 'KB',
    'CCAC': 'F1',
    'CCCC': 'P4',
    'CCCG': 'S8',
    'CCAG': 'UB',
    'CCUG': 'Y1',
    'CCGG': 'V4',
    'CUGA': 'E9',
    'CUUA': 'QC',
    'CUAA': 'H2',
    'CUCA': 'I5',
    'CUCU': 'A9',
    'CUAU': 'RC',
    'CUUU': 'D2',
    'CUGU': 'C5',
    'CUGC': 'L9',
    'CUUC': 'KC',
    'CUAC': 'F2',
    'CUCC': 'P5',
    'CUCG': 'S9',
    'CUAG': 'UC',
    'CUUG': 'Y2',
    'CUGG': 'V5',
    'AUGA': 'EA',
    'AUUA': 'QD',
    'AUAA': 'H3',
    'AUCA': 'I6',
    'AUCU': 'AA',
    'AUAU': 'RD',
    'AUUU': 'D3',
    'AUGU': 'C6',
    'AUGC': 'LA',
    'AUUC': 'KD',
    'AUAC': 'F3',
    'AUCC': 'P6',
    'AUCG': 'SA',
    'AUAG': 'UD',
    'AUUG': 'Y3',
    'AUGG': 'V6',
    'UUGA': 'EB',
    'UUUA': 'G1',
    'UUAA': 'H4',
    'UUCA': 'I7',
    'UUCU': 'AB',
    'UUAU': 'N1',
    'UUUU': 'D4',
    'UUGU': 'C7',
    'UUGC': 'LB',
    'UUUC': 'M1',
    'UUAC': 'F4',
    'UUCC': 'P7',
    'UUCG': 'SB',
    'UUAG': 'W1',
    'UUUG': 'Y4',
    'UUGG': 'V7',
    'GUGA': 'EC',
    'GUUA': 'G2',
    'GUAA': 'H5',
    'GUCA': 'I8',
    'GUCU': 'AC',
    'GUAU': 'N2',
    'GUUU': 'D5',
    'GUGU': 'C8',
    'GUGC': 'LC',
    'GUUC': 'M2',
    'GUAC': 'F5',
    'GUCC': 'P8',
    'GUCG': 'SC',
    'GUAG': 'W2',
    'GUUG': 'Y5',
    'GUGG': 'V8',
    'GAGA': 'ED',
    'GAUA': 'G3',
    'GAAA': 'H6',
    'GACA': 'I9',
    'GACU': 'AD',
    'GAAU': 'N3',
    'GAUU': 'D6',
    'GAGU': 'C9',
    'GAGC': 'LD',
    'GAUC': 'M3',
    'GAAC': 'F6',
    'GACC': 'P9',
    'GACG': 'SD',
    'GAAG': 'W3',
    'GAUG': 'Y6',
    'GAGG': 'V9',
    'UAGA': 'Q1',
    'UAUA': 'G4',
    'UAAA': 'H7',
    'UACA': 'IA',
    'UACU': 'R1',
    'UAAU': 'N4',
    'UAUU': 'D7',
    'UAGU': 'CA',
    'UAGC': 'K1',
    'UAUC': 'M4',
    'UAAC': 'F7',
    'UACC': 'PA',
    'UACG': 'U1',
    'UAAG': 'W4',
    'UAUG': 'Y7',
    'UAGG': 'VA',
    'AAGA': 'Q2',
    'AAUA': 'G5',
    'AAAA': 'H8',
    'AACA': 'IB',
    'AACU': 'R2',
    'AAAU': 'N5',
    'AAUU': 'D8',
    'AAGU': 'CB',
    'AAGC': 'K2',
    'AAUC': 'M5',
    'AAAC': 'F8',
    'AACC': 'PB',
    'AACG': 'U2',
    'AAAG': 'W5',
    'AAUG': 'Y8',
    'AAGG': 'V',
    'CAGA': 'Q3',
    'CAUA': 'G6',
    'CAAA': 'H9',
    'CACA': 'IC',
    'CACU': 'R3',
    'CAAU': 'N6',
    'CAUU': 'D9',
    'CAGU': 'CC',
    'CAGC': 'K3',
    'CAUC': 'M6',
    'CAAC': 'F9',
    'CACC': 'PC',
    'CACG': 'U3',
    'CAAG': 'W6',
    'CAUG': 'Y9',
    'CAGG': 'VC'

}
intronsequence="ACAT-ACTG-ACCC-ACGA-TCAT-TCTG-TCCG-TCGT-CCAG-CCTA-CCCG-CCGG-GCAA-GCTT-GCCG-GCGC-ACTC-ACCG-TCTC-TCCC-CCCC-GCTA-GCCC-ATAA-ACTG-ATTT-ATGC-TTAA-TTTT-TTCC-TTGG-CTAT-CTTG-CTCC-CTGA-GTAT-GTTG-GTCG-GTGT-ATTA-ATCC-TTTA-TACG-TTCG-CTTC-GTTC-GACC"
DNA_TO_ASCII = {
    "ACAT": "a",
    "ACTG": "b",
    "ACCC": "c",
    "ACGA": "d",
    "TCAT": "e",
    "TCTG": "f",
    "TCCG": "g",
    "TCGT": "h",
    "CCTA": "i",
    "CCAG": "j",
    "CCCG": "k",
    "CCGG": "l",
    "GCAA": "m",
    "GCTT": "n",
    "GCCG": "o",
    "GCGC": "p",
    "ACTC": "q",
    "ACCG": "r",
    "TCTC": "s",
    "TCCC": "t",
    "CCTT": "u",
    "CCCC": "v",
    "GCTA": "w",
    "GCCC": "x",
    "AAAA": "y",
    "AATT": "z",
    "AACC":"A",
    "AAGG":"B",
    "TAAT":"C",
    "TATG":"D",
    "TACC":"E",
    "TAGA":"F",
    "CAAT":"G",
    "CATG":"H",
    "CACG":"I",
    "CAGT":"J",
    "GAAG":"K",
    "GATA":"L",
    "GACG":"M",
    "GAGG":"N",
    "AATA":"O",
    "AACG":"P",
    "TATC":"Q",
    "TACG":"R",
    "CATC":"S",
    "CACC":"T",
    "GATT":"U",
    "GACC":"V",
    "ATAA":"W",
    "ATTT":"X",
    "ATCG":"Y",
    "ATGC":"Z",
    "TTAA":"0",
    "TTTT":"1",
    "TTCC":"2",
    "TTGG":"3",
    "CTAT":"4",
    "CTTG":"5",
    "CTCC":"6",
    "CTGA":"7",
    "GTAT":"8",
    "GTTG":"9",
    "TGTA":"@"

}
dnatobinary={"A":"00","T":"01","C":"10","G":"11"}
intronbinary1="00011011"
intronbinary2="10110001"



def binary_exnor(str1, str2):
    result = ''.join('1' if bit1 == bit2 else '0' for bit1, bit2 in zip(str1, str2))
    return result

def trnaconversion(mrna):
      output=""
      for i in mrna:
        if(i=="A"):
          output+="U"
        elif(i=="U"):
          output+="A"
        elif(i=="G"):
          output+="C"
        elif(i=="C"):
          output+="G"
      return output
def trnatodna(trna):
  output=""
  for i in trna:
    if(i!="U"):
      output+=i
    else:
      output+="T"
  return  output
def rightshift(dna):
  output=dna[-1]+dna[0:len(dna)-1]
  return output

def mrnatranslate(trna):
  output=""
  for k in trna:
      if(k!='T'):
        output+=k
      else:
        output+='U'
  return output

def encryption(text):
  extracted_letters=list(text)
  first=extracted_letters[0]
  second=extracted_letters[1]
  first_dna=None
  second_dna=None
  for i in DNA_TO_ASCII:
    if(DNA_TO_ASCII[i]==first):
      first_dna=i
    if(DNA_TO_ASCII[i]==second):
      second_dna=i

    if(first_dna!=None and second_dna!=None):
      break
  for i in range(10):
    firstbinary=""
    secondbinary=""
    for j in range(4):
      firstbinary+=dnatobinary[first_dna[j]]
      secondbinary+=dnatobinary[second_dna[j]]
    transformedfirst=binary_exnor(intronbinary1,firstbinary)
    transformedsecond=binary_exnor(intronbinary2,secondbinary)
    transformeddnafirst=""
    transformeddnasecond=""
    for j in range(0,7,2):
      ch1=transformedfirst[j:j+2]
      ch2=transformedsecond[j:j+2]
      for k in dnatobinary:
        if(dnatobinary[k]==ch1):
          transformeddnafirst+=k
        if(dnatobinary[k]==ch2):
          transformeddnasecond+=k
#mrna translation
    transformedmrnafirst=""
    transformedmrnasecond=""
    for k in transformeddnafirst:
      if(k!='T'):
        transformedmrnafirst+=k
      else:
        transformedmrnafirst+='U'
    for k in transformeddnasecond:
      if(k!='T'):
        transformedmrnasecond+=k
      else:
        transformedmrnasecond+='U'

#trna conversion
    trnafirst=trnaconversion(transformedmrnafirst)
    trnasecond=trnaconversion(transformedmrnasecond)
#todna
    prednafirst=trnatodna(trnafirst)
    prednasecond=trnatodna(trnasecond)
#shifting
    first_dna=rightshift(prednafirst)
    second_dna=rightshift(prednasecond)
  print(first_dna,second_dna)
#aminoacidconversion
  mrna_first=mrnatranslate(first_dna)
  mrna_second=mrnatranslate(second_dna)
  #print(mrna_first,mrna_second)
  trnafinal1=trnaconversion(mrna_first)
  trnafinal2=trnaconversion(mrna_second)
  #print(trnafinal1,trnafinal2)
  #print(aminoacid[trnafinal1],aminoacid[trnafinal2])
  out=[aminoacid[trnafinal1],aminoacid[trnafinal2]]
  return out




def reverse_exnor(str1, str2):
    result = ''.join('1' if bit1 == bit2 else '0' for bit1, bit2 in zip(str1, str2))
    return result

def backtomrna(trna):
    output=""
    for i in trna:
        if(i=="A"):
            output+="U"
        elif(i=="U"):
            output+="A"
        elif(i=="G"):
            output+="C"
        elif(i=="C"):
            output+="G"
    return output

def backtodna(mrna):
    output=""
    for i in mrna:
        if(i=="U"):
            output+="T"
        else:
            output+=i
    return output

def leftshift(dna):
    
    output=dna[1:len(dna)]+dna[0]
    return output

def mrnaconvert(trna):
  output=""
  for k in trna:
      if(k!='T'):
        output+=k
      else:
        output+='U'
  return output

def decryption(cipher):
    first_cipher=cipher[0]
    second_cipher=cipher[1]

    for i in aminoacid:
        if(aminoacid[i]==first_cipher):
            first_cipher=i
        if(aminoacid[i]==second_cipher):
            second_cipher=i
    backmrna1=backtomrna(first_cipher)
    backmrna2=backtomrna(second_cipher)
    backtodna1=backtodna(backmrna1)
    backtodna2=backtodna(backmrna2)
    #print(backtodna1,backtodna2)
    for i in range(10):
      #leftshift
          leftshift1=leftshift(backtodna1)
          leftshift2=leftshift(backtodna2)
          #print(leftshift1,leftshift2)
      #mrnaconversion
          mrna1=mrnaconvert(leftshift1)
          mrna2=mrnaconvert(leftshift2)
          #print(mrna1,mrna2)
          mrna1=backtomrna(mrna1)
          mrna2=backtomrna(mrna2)
          #print(mrna1,mrna2)
          predna1=backtodna(mrna1)
          predna2=backtodna(mrna2)
          #print(predna1,predna2)
          firstbinary=""
          secondbinary=""
          for j in range(4):
                   firstbinary+=dnatobinary[predna1[j]]
                   secondbinary+=dnatobinary[predna2[j]]
          #print(firstbinary,secondbinary)
          dna1=reverse_exnor(intronbinary1,firstbinary)
          dna2=reverse_exnor(intronbinary2,secondbinary)
          #print(dna1,dna2)
          backtodna1=""
          backtodna2=""
          for j in range(0,7,2):
                 ch1=dna1[j:j+2]
                 ch2=dna2[j:j+2]
                 for k in dnatobinary:
                         if(dnatobinary[k]==ch1):
                                backtodna1+=k
                         if(dnatobinary[k]==ch2):
                                backtodna2+=k
          #print(backtodna1,backtodna2)
    decryptedtext=[DNA_TO_ASCII[backtodna1],DNA_TO_ASCII[backtodna2]]
    return decryptedtext
























def first(request):
    
    return render(request,'front/home.html')
def encrypt(request):
    return render(request,'front/encrypt.html')    

def decrypt(request):
    return render(request,'front/decrypt.html')

def getdata(request):
    print(88)
    if(request.method=="POST"):

          text=request.POST.get('data')
          print(text)
          lis=text.split()
          output=""
          plaintext=[]
          for i in lis:
               output+=i
          print(output)
          if(len(output)%2==0):
                 for i in range(0,len(output),2):
                       plaintext.append([output[i],output[i+1]])
          else:
                 for i in range(0,len(output)-1,2):
                        plaintext.append([output[i],output[i+1]])
                 plaintext.append([output[-1],"@"]) 
          cipher=[]

          for i in range(len(plaintext)):
                output=encryption(plaintext[i])
                cipher.append(output)
         
          ciphertext=""
          for i in cipher:
                ciphertext+=i[0]
                ciphertext+=i[1]
          print(ciphertext)
          return render(request, 'front/encrypt.html',{'ciphertext':ciphertext}) 

          
    

                      
    return render(request, 'front/encrypt.html') 


def senddata(request):
    if request.method=="POST":
        data=request.POST.get("cipher")
        print(data)
        cipherblock=[]
        for i in range(0,len(data)-1,2):
                 t=""
                 t+=data[i]
                 t+=data[i+1]
                 cipherblock.append(t)
        print(cipherblock)
        decryptedtext=""
        for i in range(0,len(cipherblock)-1,2):
               output=decryption([cipherblock[i],cipherblock[i+1]])
               decryptedtext+=output[0]+output[1]
        print(decryptedtext)

        if(decryptedtext[-1]=="@"):
                     decryptedtext=decryptedtext[0:len(decryptedtext)-1]

        print(decryptedtext)
        return render(request,'front/decrypt.html',{'plaintext':decryptedtext})
    return render(request,'front/decrypt.html')    